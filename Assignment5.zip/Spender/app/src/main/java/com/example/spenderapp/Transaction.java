package com.example.spenderapp;

public class Transaction {
    public int tId;
    public String desc, tDate;
    public float amount;
    public  Transaction(int id, String date, String reason,  float money){
        tId = id;
        desc = reason;
        tDate = date;
        amount = money;
    }
    public  String toSQL(){
        StringBuilder sb = new StringBuilder("(");
        sb.append(tId).append(",");
        sb.append("\"").append(tDate).append("\"").append(",");
        sb.append(amount).append(",");
        sb.append("\"").append(desc).append("\"").append(")");
        return sb.toString();
    }
}
